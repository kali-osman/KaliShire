
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <link rel="icon" href="../bootstrap/assets/evot.jpg">
    <title>View Candidates</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- custom css -->
    <link href="../css/dashboard.css" rel="stylesheet">
    <link href="../css/album.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
  </head>
  <body class="text-danger">
<?php
include 'php/dbcon.php';
$query = "SELECT * FROM candidates";
$result = mysqli_query($con,$query);
?>
    <header>
  <nav class="navbar navbar-dark fixed-top flex-md-nowrap p-0 shadow" id="nav">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="dashboard.php">E-Voting</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" id="signO" href="php/sessionD.php">Sign out</a>
        </li>
      </ul>
    </nav>
</header>
<div class="container-fluid">
      <div class="col">
        <nav class="col-md-2 d-none d-md-block sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active text-danger" href="dashboard.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="dashboard.php">
                  <span data-feather="file" class="text-danger"></span>
                  Current Progress
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="add_candidate.php">
                  <span data-feather="user-plus" class="text-danger"></span>
                  Add Candidate
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="view.php">
                  <span data-feather="users" class="text-danger"></span>
                  View Candidates
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="Voters.php">
                  <span data-feather="users" class="text-danger"></span>
                  View voters
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="results.php">
                  <span data-feather="bar-chart-2" class="text-danger"></span>
                  Results
                </a>
              </li>
            </ul>

<!--             <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle" ></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
          </div>
        </nav>
      </div>
    </div>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
  <div>
   <h1 class="h3 mb-3 font-weight-normal text-center"> Candidates</h1>
  </div>
  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row">
        <?php
        while($record = mysqli_fetch_array($result)){
         ?>
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="../images/candidates/<?php echo $record['Image']; ?>" width="100%" height="100%" style="min-height: 450px;" alt="<?php echo $record[2]." ".$record[3]; ?>">
            <div class="card-body">
              <p class="card-text">POST <br><?php echo $record[7]; ?></p>
              <p class="card-text">NAME <br><?php echo $record[2]." ".$record[3]; ?></p>
              <p class="card-text">FACAULTY <br><?php echo $record[4]; ?></p>
              <p class="card-text">COURSE <br><?php echo $record[5]; ?></p>
              <p class="card-text">NATIONALITY <br><?php echo $record[6]; ?></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-danger">
                    <a href="<?php echo "php/del.php?RegNo=$record[1]";?>">Delete</a>
                  </button>
                </div>
                <button type="button" class="btn btn-sm btn-danger">
                  <a href="<?php echo "edit.php?RegNo=$record[1]";?>">Edit</a>
                </button>
              </div>
            </div>
          </div>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>

</main>

<footer class="text-muted" id="foot">
</footer>

<!-- icons -->
<script src="../bootstrap/icon/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
</body>
</html>
