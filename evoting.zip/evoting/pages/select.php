<?php

//$con=@mysql_connect("localhost","root",'') or die('can not connect') ;
//$db=@mysql_select_db("e-voting",$con) or die('can not connect to db');


$con=mysql_connect('localhost','root','');
$db=mysql_select_db('e-voting', $con);



 

if (isset($_POST['submit'])) {



 $stdRegno= $_POST['RegNo'];
//$stdstatus=$_POST['status'];
  


  $query= mysql_query(" SELECT  id,status from students where   Regno= '$stdRegno'");



   if(mysql_num_rows($query) == 1 )
   {

      $run=mysql_fetch_array($query);
      $stdstatus=$run['status'];
          if($stdstatus == "not paid") {
          echo "please pay 50% of the fee to continue voting process";
      }

          
   else{
   	 $_SESSION['students']=$_POST['RegNo'];
      header('location:View.php');
   }
      
    
}

     else {
       echo "some thing went wrong".mysql_error();
     }  
    


}



?>