
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../bootstrap/assets/evot.jpg">

    <title>Voting</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/adminP.css" rel="stylesheet">
    <link href="../css/student.css" rel="stylesheet">

  </head>


  <header>
    <nav class="navbar navbar-dark fixed-top flex-md-nowrap p-0 shadow" id="nav">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="students.php">E-Voting</a>
  </nav>
  </header>
      <!-- alert -->


<body>

  <!---
  <div class="container">
<?php 
session_start();
if (isset($_SESSION['response'])) {
?>
    <div class="alert  alert-success alert-dismissible"> 
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <p><strong><?php echo $_SESSION["response"]; ?></strong></p>
    <?php } unset($_SESSION['response']);
    
   if(!isset($_SESSION['regno'])) {

    ?>
    <div class="alert alert-<?php echo $_SESSION['response1']; ?>  alert-success alert-dismissible  " role="alert"  > 
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <p><strong><?php echo $_SESSION["response1"]; ?></strong></p>
    <?php } unset($_SESSION['response1']);
     
   
   

   
   
      ?>



    </div>
    --->
     

    <div class="row col-md-12 text-center">
      <form class="form-signin" action="php/check.php" method="POST">
        <img class="mb-4" src="../bootstrap/assets/evot.jpg" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal text-danger">Registration Number</h1>
        <input type="text" id="inputPassword" class="form-control" placeholder="Registration Number" name="RegNo" required>
        <button class="btn btn-lg btn-block btn-danger" id="bts" type="submit" name="check" value="check">Check
        </button>
        <p class="mt-5 mb-3 text-muted">
          <!-- <img class="mb-4" src="../bootstrap/assets/evot.jpg" alt="" width="19" height="19">-->&copy;
          <?php echo date('Y'); ?></p>
      </form>
    </div>
  </div>
  <footer>
    <script src="../bootstrap/js/jquery-3.3.1.min.js"></script>
  </footer>
</body>
</html>
