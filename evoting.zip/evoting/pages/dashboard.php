<?php
session_start();
include 'php/dbcon.php';
// $query = "SELECT * FROM voters";
// $result = mysqli_query($con,$query);
$sql ="SELECT candidates.fname, candidates.lname, candidates.post,candidates.Image, COUNT(voters.cand_name) as results FROM candidates LEFT OUTER join voters on candidates.fname=voters.cand_name GROUP BY candidates.fname";
$reslt  = mysqli_query($con, $sql);


while($record = mysqli_fetch_array($reslt)){
  extract($record);
  $json[] = $record['fname'];
  // echo $voters_regno;
  $jsoni[] = $record['results'];
}
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../bootstrap/assets/evot.jpg">

    <title>Dashboard</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bootstrap/css/jquery.dataTables.min.css">

    <!-- Custom styles for this template -->
    <link href="../css/dashboard.css" rel="stylesheet">
  </head>

  <body class="text-danger" id="body">
    <?php
include 'php/dbcon.php';
$sql ="SELECT candidates.fname, candidates.lname, candidates.post,candidates.Image, COUNT(voters.cand_name) as results FROM candidates LEFT OUTER join voters on candidates.fname=voters.cand_name GROUP BY candidates.fname";
$rslt  = mysqli_query($con, $sql);
$query = "SELECT * FROM voters";
$result = mysqli_query($con,$query);

?>
    <nav class="navbar navbar-dark fixed-top flex-md-nowrap p-0 shadow" id="nav">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">E-Voting</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" id="signO" href="php/sessionD.php">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="col">
        <nav class="col-md-2 d-none d-md-block sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active text-danger" href="dashboard.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="dashboard.php">
                  <span data-feather="file" class="text-danger"></span>
                  Current Progress
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="add_candidate.php">
                  <span data-feather="user-plus" class="text-danger"></span>
                  Add Candidate
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="view0.php">
                  <span data-feather="users" class="text-danger"></span>
                  View Candidates
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="Voters.php">
                  <span data-feather="users" class="text-danger"></span>
                  View voters
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="results.php">
                  <span data-feather="bar-chart-2" class="text-danger"></span>
                  Results
                </a>
              </li>
            </ul>

<!--             <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle" ></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2 text-danger">Current Voting Status</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-danger"><?php echo $_SESSION['email']; ?></button>
                <!-- <button class="btn btn-sm btn-outline-secondary">Export</button> -->
              </div>
<!--               <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button> -->
            </div>
          </div>
          <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>
          <h2 class="text-danger">Results</h2>
          <div class="table-responsive" style="min-height: 500px;">
            <table class="table table-striped table-sm table-hover text-danger">
              <thead>
                <tr>
                  <th>Candidates Name</th>
                  <th>Candidates Votes</th>
                </tr>
              </thead>
              <tbody>
                    <?php
                      while($rec = mysqli_fetch_array($rslt)){
                    ?>
                  <tr>
                  <td><?php echo $rec['fname']; ?></td>
                  <td><?php echo $rec['results']; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
            </table>
          </div>
          <h2 class="text-danger">Voters Progress</h2>
          <div class="table-responsive" style="min-height: 500px;">
            <table class="table table-striped table-sm table-hover text-danger">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Voters RegNo</th>
                  <th>Candidates RegNo</th>
                </tr>
              </thead>
              <tbody>
                              <?php
                      while($record = mysqli_fetch_array($result)){
                            ?>
                  <tr>
                  <td><?php echo $record[0]; ?></td>
                  <td><?php echo $record[1]; ?></td>
                  <td><?php echo $record[2]; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
            </table>
          </div>
          <div class="text-right">
          <button class="btn btn-lg btn-danger" id="btv" type="submit"><a href="voters.php">view more voters</a></button>
          </div>
        </main>
      </div>
    </div>
    <footer class="text-muted" id="foot">
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="../bootstrap/js/jquery-3.3.1.min.js"></script>
    <script src="../bootstrap/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/dataTables.bootstrap4.min.js"></script>
    <!-- datatables -->
    <!-- <script type="text/javascript">
      $(document).ready(function(){
        $(".table").DataTable();
      })
    </script> -->

    <!-- Icons -->
    <script src="../bootstrap/icon/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="../bootstrap/chart/Chart.min.js"></script>
    <script>
      var ctx = document.getElementById("myChart");
      var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: <?php echo json_encode($json); ?>,
          datasets: [{
            data: <?php echo json_encode($jsoni); ?>,
            lineTension: 0,
            backgroundColor: 'maroon',
            borderColor: 'grey',
            borderWidth: 3,
            pointBackgroundColor: 'grey'
          }]
        },
        options: {
          // scales: {
          //   yAxes: [{
          //     ticks: {
          //       beginAtZero: false
          //     }
          //   }]
          // },
          legend: {
            display: false,
          }
        }
      });
    </script>
  </body>
</html>
