
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../bootstrap/assets/evot.jpg">

    <title>E-voting</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bootstrap/css/jquery.dataTables.min.css">

    <!-- Custom styles for this template -->
    <link href="../css/dashboard.css" rel="stylesheet">
  </head>
  <body class="text-danger">
<?php
include 'php/dbcon.php';
$query = "SELECT * FROM voters";
$result = mysqli_query($con,$query);
?>
    <nav class="navbar navbar-dark fixed-top flex-md-nowrap p-0 shadow" id="nav">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="dashboard.php">E-Voting</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link hover" id="signO" href="php/sessionD.php">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active text-danger" href="dashboard.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="dashboard.php">
                  <span data-feather="file" class="text-danger"></span>
                  Current Progress
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="add_candidate.php">
                  <span data-feather="user-plus" class="text-danger"></span>
                  Add Candidate
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="view.php">
                  <span data-feather="users" class="text-danger"></span>
                  View candidates
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="voters.php">
                  <span data-feather="users" class="text-danger"></span>
                  View voters
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="results.php">
                  <span data-feather="bar-chart-2" class="text-danger"></span>
                  Results
                </a>
              </li>
            </ul>

<!--             <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle" ></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
          </div>
        </nav>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <h1 class="h2 text-danger text-center">Current Voters</h1>
          <div class="table-responsive" style="min-height: 500px;">
            <table class="table table-striped table-sm table-hover text-danger">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Voters RegNo</th>
                  <th>Candidates Name</th>
                </tr>
              </thead>
              <tbody>
<?php
    while($record = mysqli_fetch_array($result)){
?>
                <tr>
                  <td><?php echo $record[0]; ?></td>
                  <td><?php echo $record[1]; ?></td>
                  <td><?php echo $record[2]; ?></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
    <footer class="text-muted" id="foot">
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="../bootstrap/js/jquery-3.3.1.min.js"></script>
    <script src="../bootstrap/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/dataTables.bootstrap4.min.js"></script>
    <!-- datatables -->
    <script type="text/javascript">
      $(document).ready(function(){
        $(".table").DataTable();
      })
    </script>

    <!-- Icons -->
    <script src="../bootstrap/icon/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
  </body>
</html>
