
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../bootstrap/assets/evot.jpg">

    <title>Edit Candidate</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/addCand.css" rel="stylesheet">
    <link href="../css/dashboard.css" rel="stylesheet">
  </head>

  <body class="text-danger">
<?php
include 'php/dbcon.php';
if(isset($_GET['RegNo'])){
$id = $_GET['RegNo'];

$query = "SELECT * FROM candidates WHERE RegNo = '$id'";
$result = mysqli_query($con,$query);
$record = mysqli_fetch_array($result);
?>
    <nav class="navbar navbar-dark fixed-top flex-md-nowrap p-0 shadow" id="nav">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="dashboard.php">E-Voting</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" id="signO" href="php/sessionD.php">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="col">
        <nav class="col-md-2 d-none d-md-block sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active text-danger" href="dashboard.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="dashboard.php">
                  <span data-feather="file" class="text-danger"></span>
                  Current Progress
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="add_candidate.php">
                  <span data-feather="user-plus" class="text-danger"></span>
                  Add Candidate
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="view.php">
                  <span data-feather="users" class="text-danger"></span>
                  View candidates
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="Voters.php">
                  <span data-feather="users" class="text-danger"></span>
                  View voters
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-danger" href="results.php">
                  <span data-feather="bar-chart-2" class="text-danger"></span>
                  Results
                </a>
              </li>
            </ul>

<!--             <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle" ></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
          </div>
        </nav>
      </div>
    </div>
    <form class="form-signin hover" action="php/update.php" method="POST" enctype="multipart/form-data">
      <img class="mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="0" height="10">
      <h1 class="h3 mb-3 font-weight-normal">Edit Candidate</h1>
      <input type="hidden" id="inputEmail" class="form-control" name="id" value="<?php echo $record[0];?>" placeholder="ID" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="regno" value="<?php echo $record[1];?>" placeholder="Reg.No" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="fname" value="<?php echo $record[2];?>" placeholder="First Name" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="lname" value="<?php echo $record[3];?>" placeholder="Last Name" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="fac" value="<?php echo $record[3];?>" placeholder="Faculty" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="cos" value="<?php echo $record[5];?>" placeholder="Course" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="nat" value="<?php echo $record[6];?>" placeholder="Nationality" required autofocus>
      <input type="text" id="inputEmail" class="form-control" name="post" value="<?php echo $record[7];?>" placeholder="Post" required autofocus>
      <input type="file" id="inputEmail" class="form-control" name="img" required autofocus>
      </div><br>
      <button class="btn btn-danger btn-block" id="ab" type="submit" name="addCand" value="addCand">
        Update
      </button>
    </form>
  <?php } ?>
    <footer id="foot">
      <p class="text-muted text-center ">&copy; Copyright 2017-2018</p>
    </footer>
    <!-- Icons -->
    <script src="../../bootstrap/icon/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
  </body>
</html>
