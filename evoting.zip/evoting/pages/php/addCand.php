<?php
include 'dbcon.php';
if(isset($_POST['addCand'])){

	$url = "../../images/candidates/".basename($_FILES['img']['name']);

	$regn = $_POST['regno'];
	$fnam = $_POST['fname'];
	$lnam = $_POST['lname'];
	$facu = $_POST['fac'];
	$cors = $_POST['cos'];
	$natn = $_POST['nat'];
	$pos = $_POST['post'];
	$image = $_FILES['img']['name'];

	

$query = "INSERT INTO candidates VALUES('','$regn','$fnam','$lnam','$facu','$cors','$natn','$pos','$image')";
$result = mysqli_query($con,$query)or die(mysqli_error($con));

	if (move_uploaded_file($_FILES['img']['tmp_name'], $url)) {
			echo "upload success";
		}

if ($result) {
	header("Location:../view.php");
}

}
?>