<?php
include 'dbcon.php';
if(isset($_POST['addCand'])){

	$url = "../../images/candidates/".basename($_FILES['img']['name']);

	$id   = $_POST['id'];
	$regn = $_POST['regno'];
	$fnam = $_POST['fname'];
	$lnam = $_POST['lname'];
	$facu = $_POST['fac'];
	$cors = $_POST['cos'];
	$natn = $_POST['nat'];
	$pos = $_POST['post'];
	$image = $_FILES['img']['name'];

$query = "UPDATE candidates SET regno='$regn',fname='$fnam',lname='$lnam',fac='$facu',Cos='$cors',nat='$natn',post='$pos',Image='$image' WHERE ID ='$id'";
$result = mysqli_query($con,$query)or die(mysqli_error($con));

	if (move_uploaded_file($_FILES['img']['tmp_name'], $url)) {
			echo "upload success";
		}

if ($result) {
	header("Location:../view.php");
}

}
?>