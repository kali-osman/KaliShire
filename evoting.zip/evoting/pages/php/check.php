<?php
//session_start();

$con=mysqli_connect('localhost','root','');
$db=mysqli_select_db($con,'e-voting');


    if (isset($_POST['check'])) {
      $stdRegno = $_POST['RegNo'];

      $query= mysqli_query($con," SELECT  id,status from students where   RegNo= '$stdRegno'");



   if(mysqli_num_rows($query) == 1 )
   {

     

      session_start();
      $_SESSION['regno']= $stdRegno;
      $run=mysqli_fetch_array($query);
      $stdstatus=$run['status'];
          if($stdstatus == "not paid") {
          echo "please pay 50% of the fee to continue voting process";
      }

          
   else{
   	
      header('Location:../vote.php');
   }
}
      
     else {
       echo "you are not in our database ,please register at the faculty".mysqli_error($con);
     }  
 }
    
    
?>