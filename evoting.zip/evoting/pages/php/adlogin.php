<?php


$con=mysqli_connect('localhost','root','');
$db=mysqli_select_db($con,'e-voting');

if (isset($_POST['submit'])) {



	$email=$_POST['email'];
	$password=$_POST['password'];



	$query=mysqli_query($con,"SELECT id FROM admin where Email='$email'AND Password='$password' ");

	if (mysqli_num_rows($query) == 1) {
		header('location:dashboard.php');
	}else
	{
		echo "some thing went wrong".mysql_errno();
	}
}







?>