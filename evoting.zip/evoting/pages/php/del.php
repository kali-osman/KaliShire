<?php 
include 'dbcon.php';
if(isset($_GET['RegNo'])){
$id = $_GET['RegNo'];

$query = "DELETE FROM candidates WHERE RegNo = '$id'";
$result = mysqli_query($con,$query) or die(mysqli_error($result));
if ($result) {
	header("Location:../view.php");
}
}

?>