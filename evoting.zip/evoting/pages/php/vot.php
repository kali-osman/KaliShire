<?php 
session_start();
include 'dbcon.php';
if (isset($_GET['vote'])) {
	 $id       = $_GET['vote'];
	 $stdRegno = $_SESSION['regno'];

	 // session
	 $_SESSION['response']      = 'Thanks for voting';
	 $_SESSION['response1']      = 'You have already voted';
	 $_SESSION['res_type'] = "success"; 


	
 $fetch= mysqli_query($con,"SELECT id FROM voters WHERE std_regno = '$stdRegno'");
	 if (mysqli_num_rows($fetch)==1) {
	   echo "<script>alert('you have alread voted ') 
	    	window.location= '../students.php';
	    		</script>";

	
}


	elseif($_SESSION['regno']) {

		$query   = "INSERT INTO voters VALUES ('','$stdRegno','$id')";
  	    $result  = mysqli_query($con,$query)or die(mysqli_error($con));

 	if($result) {
                 //  header("Location:../students.php");
	    	echo "<script>alert('thanks for voting ') 
	    	window.location= '../students.php';
	    		</script>";

    	}
    }

/*
    if (isset($_SESSION['regno'])) {
    	echo $_SESSION['response1'] ;
    }if(!isset($_SESSION['regno'])) {
    	echo $_SESSION['response'] ;
     }

    
*/
	
	}



	// if(!$fetch) {

	//  	$query   = "INSERT INTO voters VALUES ('','$stdRegno','$id')";
	// 	$result = mysqli_query($con,$query)or die(mysqli_error($con));
		


	// 	if($result) {
 //            echo "thanks for voting";
	// 	//header("Location:../students.php");
	// 	}
	// }
	// }else{

	// 	if ($_SESSION['regno']) {
			
		

	// 		$query   = "INSERT INTO voters VALUES ('','$stdRegno','$id')";
	//      	$result = mysqli_query($con,$query)or die(mysqli_error($con));

	//      	if ($result) {
	//      		echo "<script>alert('success, you just made it ')</script>";
	//      	}
	//      }

	// }

	 





 ?>