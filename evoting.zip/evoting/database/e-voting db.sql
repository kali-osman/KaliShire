-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2020 at 07:18 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Email`, `Password`) VALUES
(2, 'liil@gmail.com', '1234liil'),
(1, 'najma123@gmail.com', 'nana123');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fac` varchar(50) NOT NULL,
  `cos` varchar(50) NOT NULL,
  `nat` varchar(50) NOT NULL,
  `post` varchar(50) NOT NULL,
  `Image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `regno`, `fname`, `lname`, `fac`, `cos`, `nat`, `post`, `Image`) VALUES
(1, '16/271/bscs-j', 'kali', 'shire', 'FTS', 'computer science', 'somali', 'president', '2018-09-14-16-02-05-982.JPG'),
(2, '16/bg/585/bsse-s', 'Kalin', 'Lysan', 'FTS', 'software engineering', 'Britain', 'president', '20200229_202035.JPG'),
(3, '16/ug/898/bsc-s', 'lysa', 'yasmine', 'fst', 'computer science', 'ugandan', 'president', 'IMG_0130 (1).JPG'),
(4, '18/288/bsce', 'Naima', 'abdi', 'Engineering', 'civil', 'somali', 'president', 'naima.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `std_regno` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `std_regno`) VALUES
(1, '16/261/bscs-j');

-- --------------------------------------------------------

--
-- Table structure for table `stdsessions`
--

CREATE TABLE `stdsessions` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stdsessions`
--

INSERT INTO `stdsessions` (`id`, `regno`) VALUES
(1, '16/261/bscs-j'),
(2, '17/298/bit-s'),
(3, '16/271/bscs-j');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `RegNo` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Faculty` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `RegNo`, `FirstName`, `LastName`, `Faculty`, `Course`, `status`) VALUES
(9, '16/255/bscs-j', 'Omar', 'abd', 'science and technology', 'IT', 'paid'),
(1, '16/261/bscs-j', 'kali', 'Osman', 'science and technology', 'BSCS', 'paid'),
(18, '16/351/bit-s', 'shadia', 'simbizi', 'fst', 'bit', 'paid'),
(16, '16/cg/402/bit-s', 'binja', 'lysa', 'fst', 'bit', 'paid'),
(17, '16/ke/767/bscs', 'moha', 'abd', 'fst', 'cs', 'paid'),
(15, '16/ug/223/bit-j', 'nicholas', 'jorams', 'fst', 'bit', 'paid'),
(6, '16/ug/229/bit-j', 'Nicholas', 'Jorams', 'fst', 'BIT', 'paid'),
(7, '16/ug/339/bit-s', 'Kiggundu', 'Nicholas', 'fst', 'bit', 'paid'),
(14, '17/232/bscs-j', 'xal', 'ALI', 'science and technology', 'computer science', 'paid'),
(5, '18/588/BSCS-S', 'lllloo', 'bbbboo', 'science and technology', 'BSCS', 'paid'),
(2, '298/789/BIT-J', 'ali', 'ali', 'science and technology', 'BSSE', 'not paid'),
(4, '299/799/BIT-J', 'xal', 'abd', 'science and technology', 'IT', 'paid'),
(10, '399/779/BIT-J', 'all', 'int', 'science and technology', 'IT', 'paid'),
(12, '399/799/BIT-J', 'kalay', 'ali', 'science and technology', 'IT', 'paid'),
(13, '498/489/BIT-J', 'kalla', 'alll', 'science and technology', 'IT', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `std_regno` varchar(50) NOT NULL,
  `cand_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `std_regno`, `cand_name`) VALUES
(70, '16/261/bscs-j', 'Kalin'),
(65, '16/cg/402/bit-s', 'Kalin'),
(66, '16/ke/767/bscs', 'bashka'),
(25, '16/ug/339/bit-s', 'ali'),
(62, '17/232/bscs-j', 'kali'),
(69, '399/799/BIT-J', 'kiggundu');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `std_regno` varchar(50) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `cand_fname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `std_regno`, `regno`, `cand_fname`) VALUES
(2, '16/255/bscs-j', '16/271/bscs-j', 'kali'),
(1, '16/261/bscs-j', '16/271/bscs-j', 'kali'),
(3, '17/232/bscs-j', '16/ug/898/bsc-s', 'kiggundu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Email`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`regno`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`std_regno`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stdsessions`
--
ALTER TABLE `stdsessions`
  ADD PRIMARY KEY (`regno`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`RegNo`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`std_regno`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`std_regno`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `regno` (`regno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stdsessions`
--
ALTER TABLE `stdsessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`regno`) REFERENCES `candidates` (`regno`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
